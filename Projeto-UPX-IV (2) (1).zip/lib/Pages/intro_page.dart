import 'package:flutter/material.dart';
import 'package:projeto_upx_iv/components/my_button.dart';

class IntroPage extends StatelessWidget {
  const IntroPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //logo
            //
            Image(
              image: AssetImage('images/logo.jpg'),
              width: 120,
              height: 120,
            ),
            const SizedBox(height: 25),

            //title
            const Text(
              "Mercadinho Local",
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            const SizedBox(height: 10),
            //subtitle
            Text(
              "Ajude um Pequeno Comércio",
              style: TextStyle(
                fontSize: 20,
                color: Theme.of(context).colorScheme.inversePrimary,
              ),
            ),
            const SizedBox(height: 10),

            //Desenvolvvedor
            Text(
              "Desenvolvido Por Thiago A. Cacuro",
              style: TextStyle(
                color: Theme.of(context).colorScheme.inversePrimary,
              ),
            ),
            const SizedBox(height: 10),

            //button
            MyButton(
              onTap: () =>
                  Navigator.pushNamed(context, '/shop_page'), // Por login aqui
              child: const Icon(Icons.arrow_forward),
            )
          ],
        ),
      ),
    );
  }
}

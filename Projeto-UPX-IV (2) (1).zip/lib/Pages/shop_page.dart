import 'package:flutter/material.dart';
import 'package:projeto_upx_iv/components/my_drawer.dart';
import 'package:projeto_upx_iv/components/my_product_tile.dart';
import 'package:projeto_upx_iv/models/product.dart';
import 'package:projeto_upx_iv/models/shop.dart';
import 'package:provider/provider.dart';

class ShoPage extends StatelessWidget {
  const ShoPage({super.key});

  @override
  Widget build(BuildContext context) {
    //acess products in shop
    final products = context.watch<Shop>().shop;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        foregroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: const Text("Mercadorias"),
        actions: [
          // Go to cart Button
          IconButton(
            onPressed: () => Navigator.pushNamed(context, '/cart_page'),
            icon: const Icon(Icons.shopping_cart),
          )
        ],
      ),
      drawer: const MyDrawer(),
      backgroundColor: Theme.of(context).colorScheme.background,
      body: ListView(
        children: [
          const SizedBox(height: 25),
          // shop title
          Center(
            child: Text("Itens"),
          ),
          // shop subtile
          Center(
            child: Text(
              "Escolha um dos itens",
              style: TextStyle(
                  color: Theme.of(context).colorScheme.inversePrimary),
            ),
          ),
          // Product list
          SizedBox(
            height: 550,
            child: ListView.builder(
              itemCount: products.length,
              scrollDirection: Axis.vertical,
              padding: EdgeInsets.all(15),
              itemBuilder: (context, index) {
                // get each product from shop
                final product = products[index];

                // return as a product tile UI
                return MyProductTile(product: product);
              },
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:projeto_upx_iv/models/product.dart';

class Shop extends ChangeNotifier {
  //Produtos à venda
  final List<Product> _shop = [
    // Produto 1
    Product(
      name: "Arroz",
      price: 14.99,
      description: "Arroz Branco",
      imagePath: 'images/arroz-branco.jpg',
    ),
    // Produto 2
    Product(
      name: "Feijão",
      price: 8.99,
      description: "Feijâo Carioca",
      imagePath: 'images/arroz-branco.jpg',
    ),

    //Produto 3
    Product(
      name: "Maça Gala",
      price: 4.99,
      description: "Maça Gala (1kg)",
      imagePath: 'images/maca_gala.jpg',
    ),

    //Produto 4
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),

    //Produto 5
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),
//Produto 6
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),
    //Produto 7
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),

    //Produto 8
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),

    //Produto 9
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),

    //Produto 10
    Product(
      name: "Coca-cola",
      price: 8.99,
      description: "Garrafa de Coca Cola 2 litros",
      imagePath: 'images/coca_cola.jpg',
    ),
  ]; //aqui para cima para adicionar produtos
  //user cart
  List<Product> _cart = [];

  //get product list
  List<Product> get shop => _shop;

  //get usar cart
  List<Product> get cart => _cart;

  //add item to cart
  void addToCart(Product item) {
    _cart.add(item);
    notifyListeners();
  }

  //remove itens from cart
  void removeFromCart(Product item) {
    _cart.remove(item);
    notifyListeners();
  }
}

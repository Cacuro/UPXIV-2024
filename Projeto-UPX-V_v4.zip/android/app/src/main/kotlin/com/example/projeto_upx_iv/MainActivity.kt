package com.example.projeto_upx_iv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

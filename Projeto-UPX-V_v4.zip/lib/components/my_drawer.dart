import 'package:flutter/material.dart';
import 'package:projeto_upx_iv/components/my_list_tile.dart';

class MyDrawer extends StatelessWidget {
  const MyDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Theme.of(context).colorScheme.background,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              // drawer header:logo
              DrawerHeader(
                child: Center(
                  child: Icon(
                    Icons.shopping_bag,
                    size: 72,
                    color: Theme.of(context).colorScheme.inversePrimary,
                  ),
                ),
              ),
              const SizedBox(height: 25),

              // Shop tile
              MylistTile(
                text: "Mercadoria",
                icon: Icons.home,
                onTap: () => Navigator.pop(context),
              ),

              // cart tile
              MylistTile(
                text: "Carrinho",
                icon: Icons.shopping_bag,
                onTap: () {
                  //Pop drawer first
                  Navigator.pop(context);

                  //go to cart page
                  Navigator.pushNamed(context, '/cart_page');
                },
              ),
              // cart tile
              MylistTile(
                text: "Login",
                icon: Icons.login,
                onTap: () {
                  //Pop drawer first
                  Navigator.pop(context);

                  //go to cart page
                  Navigator.pushNamed(context, '/login_page2');
                },
              ),
            ],
          ),
          // exit shop tile
          Padding(
            padding: const EdgeInsets.only(bottom: 25.0),
            child: MylistTile(
              text: "Sair",
              icon: Icons.logout,
              onTap: () => Navigator.pushNamedAndRemoveUntil(
                  context, '/intro_page', (route) => false),
            ),
          ),
        ],
      ),
    );
  }
}

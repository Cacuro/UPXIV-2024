import 'package:flutter/material.dart';
import 'package:projeto_upx_iv/Pages/cart_page.dart';
import 'package:projeto_upx_iv/Pages/shop_page.dart';
import 'package:projeto_upx_iv/models/shop.dart';
import 'package:projeto_upx_iv/themes/light_mode.dart';
import 'package:provider/provider.dart';

import 'Pages/intro_page.dart';
import 'Pages/login_page2.dart';

void main() {
  runApp(
    ChangeNotifierProvider(
      create: (context) => Shop(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
      theme: lightMode,
      routes: {
        '/login_page2': (context) => LoginPage(),
        '/intro_page': (context) => const IntroPage(),
        '/shop_page': (context) => const ShoPage(),
        '/cart_page': (context) => const CartPage(),
        // '/login_page': (context) => const LoginPage(),
      },
    );
  }
}
